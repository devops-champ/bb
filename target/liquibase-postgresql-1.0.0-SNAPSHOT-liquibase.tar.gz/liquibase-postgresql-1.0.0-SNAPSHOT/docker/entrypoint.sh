#!/bin/bash

set -e

echo "=================================="
echo " Liquibase Container Started"
echo "=================================="

echo "Database URL:"
echo "${DB_URL}"

echo "Database User:"
echo "${DB_USERNAME}"

liquibase \
    --defaultsFile=/liquibase/liquibase.properties \
    --url="${DB_URL}" \
    --username="${DB_USERNAME}" \
    --password="${DB_PASSWORD}" \
    "$@"